package com.mohamed.parrinage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParrinageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParrinageApplication.class, args);
	}

}
